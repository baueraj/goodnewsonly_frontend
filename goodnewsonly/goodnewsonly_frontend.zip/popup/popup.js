// This script runs when the popup is opened. You can update the popup's content dynamically.
document.getElementById("status").innerText = "Finished!";
