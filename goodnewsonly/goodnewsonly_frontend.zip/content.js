chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action == "processPage") {
        // Fetch the current page's URL or content and send it to the backend
        fetch('https://your-backend-url/analyze', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({url: window.location.href}) // or send page content
        })
        .then(response => response.json())
        .then(data => {
            // Assuming the backend returns a list of headlines to obstruct
            obstructHeadlines(data.headlines);
        })
        .catch(error => {
            console.error("Error communicating with backend:", error);
        });
    }
});

function obstructHeadlines(headlines) {
    // Your logic to obstruct the specified headlines
}
